import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: LoginPage(),
  ));
}

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: NetworkImage("https://images.unsplash.com/photo-1482938289607-e9573fc25ebb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80"),
            filterQuality: FilterQuality.high,
            fit: BoxFit.cover
          )
        ),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("Login Here!",
                  style: TextStyle(color: Colors.amber, fontSize: 40.0, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 150.0,),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 40.0,),
                  child: TextFormField(
                    decoration: InputDecoration(
                      hintStyle: TextStyle(color: Colors.amber[100]),
                      hintText: "Favorite Email?",
                      labelText: "Favorite Email?",
                      labelStyle: TextStyle(color: Colors.amberAccent[200]),
                      filled: true,
                      fillColor: Colors.black87,
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 2, color: Colors.amber),
                        borderRadius: BorderRadius.all(Radius.circular(10.0))
                      ),
                    ),
                    style: TextStyle(
                      color: Colors.white
                    ),
                  ),
                ),
                SizedBox(height: 20.0,),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 40.0,),
                  child: TextFormField(
                    decoration: InputDecoration(
                      hintStyle: TextStyle(color: Colors.amber[100]),
                      hintText: "Favorite Password?",
                      labelText: "Favorite Password?",
                      labelStyle: TextStyle(color: Colors.amberAccent[200]),
                      filled: true,
                      fillColor: Colors.black87,
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 2, color: Colors.amber),
                        borderRadius: BorderRadius.all(Radius.circular(10.0))
                      ),
                    ),
                    style: TextStyle(
                      color: Colors.white
                    ),
                    obscureText: true,
                    obscuringCharacter: "*",
                  ),
                ),
                SizedBox(height: 50.0,),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 40.0,),
                  child: ElevatedButton.icon(
                    onPressed: (){

                    },
                    label: Text("Access Home Page", style: TextStyle(fontSize: 20.0),),
                    icon: Icon(Icons.login_sharp),
                    style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.all(15.0),
                        foregroundColor: Colors.black87,
                        backgroundColor: Colors.amberAccent[200]
                    ),
                  ),
                ),
                SizedBox(height: 150.0,),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Text("© Copyright 2022. Muhammad Wahid Akram",
                    style: TextStyle(color: Colors.white, fontSize: 15.0),
                  ),
                )
              ],
            )
          ),
        ),
      ),
    );
  }
}
